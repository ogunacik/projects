import argparse
from pathlib import Path
from typing import Any, Dict, List, Optional
import logging
import warnings

import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
import urllib3


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings(
	"ignore",
	message=r".*Boto3 will no longer support Python 3\.6.*",
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

CONFIG_PATH = Path(__file__).with_name("s3_config.toml")


def _read_toml(config_path: Path) -> Dict[str, Any]:
	"""Read TOML using stdlib on new Python versions and tomli on older versions."""
	try:
		import tomllib  # type: ignore[attr-defined]

		with config_path.open("rb") as handle:
			return tomllib.load(handle)
	except ModuleNotFoundError:
		try:
			import tomli  # type: ignore[import-not-found]

			with config_path.open("rb") as handle:
				return tomli.load(handle)
		except ModuleNotFoundError as exc:
			raise RuntimeError(
				"TOML parser unavailable. Install tomli for Python < 3.11: pip install tomli"
			) from exc


def load_s3_config(config_path: Path = CONFIG_PATH) -> Dict[str, str]:
	"""Load and validate S3 connection configuration from a TOML file."""
	if not config_path.is_file():
		raise FileNotFoundError(f"S3 config file not found: {config_path}")

	data = _read_toml(config_path)
	s3_config = data.get("s3", data)
	required = ["server", "bucket", "access_key_id", "secret", "region"]
	missing = [name for name in required if not s3_config.get(name)]
	if missing:
		raise ValueError(f"Missing required config values in {config_path}: {', '.join(missing)}")

	return {name: str(s3_config[name]) for name in required}


_config = load_s3_config()
server = _config["server"]
bucket = _config["bucket"]
access_key_id = _config["access_key_id"]
secret = _config["secret"]
region = _config["region"]


def parse_cli_args() -> argparse.Namespace:
	"""Parse CLI arguments for runtime bucket and source file selection."""
	parser = argparse.ArgumentParser(description="S3 connectivity helper")
	parser.add_argument(
		"--source-file",
		default="connectivity-test.txt",
		help="Local file path to upload before running other checks",
	)
	parser.add_argument(
		"--bucket",
		default=bucket,
		help="Bucket name to use for all operations",
	)
	return parser.parse_args()


def create_s3_client(verify_ssl: bool = True):
	"""Create an S3-compatible client from the configured connection values."""
	return boto3.client(
		"s3",
		endpoint_url=server,
		aws_access_key_id=access_key_id,
		aws_secret_access_key=secret,
		region_name=region,
		config=Config(signature_version="s3v4", s3={"addressing_style": "path"}),
		verify=verify_ssl,
	)


def create_bucket(bucket_name: Optional[str] = None, verify_ssl: bool = False) -> bool:
	"""Create a bucket if needed. Returns True when created or already exists."""
	client = create_s3_client(verify_ssl=verify_ssl)
	target_bucket = bucket_name or bucket

	try:
		if region == "us-east-1":
			client.create_bucket(Bucket=target_bucket)
		else:
			client.create_bucket(
				Bucket=target_bucket,
				CreateBucketConfiguration={"LocationConstraint": region},
			)
		logger.info("Bucket is ready: %s", target_bucket)
		return True
	except ClientError as exc:
		error_code = exc.response.get("Error", {}).get("Code", "")
		if error_code in {"BucketAlreadyOwnedByYou", "BucketAlreadyExists"}:
			logger.info("Bucket already exists: %s", target_bucket)
			return True
		logger.error("Bucket creation failed for '%s': %s", target_bucket, exc)
		return False


def test_simple_upload(
	object_key: str,
	content: str = "s3 upload test",
	verify_ssl: bool = False,
) -> bool:
	"""Upload a small text object and create the bucket on-demand if missing."""
	client = create_s3_client(verify_ssl=verify_ssl)
	try:
		client.put_object(Bucket=bucket, Key=object_key, Body=content.encode("utf-8"))
		logger.info("Upload succeeded for key: %s", object_key)
		return True
	except ClientError as exc:
		error_code = exc.response.get("Error", {}).get("Code", "")
		if error_code in {"NoSuchBucket", "NotFound", "404"}:
			logger.warning("Bucket missing during upload; attempting to create bucket: %s", bucket)
			if create_bucket(verify_ssl=verify_ssl):
				try:
					client.put_object(Bucket=bucket, Key=object_key, Body=content.encode("utf-8"))
					logger.info("Upload succeeded after bucket creation for key: %s", object_key)
					return True
				except ClientError as retry_exc:
					logger.error("Upload retry failed for '%s': %s", object_key, retry_exc)
					return False
		logger.error("Upload failed for '%s': %s", object_key, exc)
		return False


def upload_file(
	file_path: str,
	object_key: Optional[str] = None,
	verify_ssl: bool = False,
) -> bool:
	"""Upload a local file. Returns False when source file does not exist."""
	source = Path(file_path)
	if not source.is_file():
		logger.error("Source file not found: %s", source)
		return False

	key = object_key or source.name
	content = source.read_text(encoding="utf-8")
	return test_simple_upload(key, content=content, verify_ssl=verify_ssl)


def test_simple_download(
	object_key: str,
	output_path: Optional[str] = None,
	verify_ssl: bool = False,
) -> Optional[str]:
	"""Download an object and return local file path, or None on failure."""
	client = create_s3_client(verify_ssl=verify_ssl)
	local_path = Path(output_path or f"{object_key.replace('/', '_')}.download")

	try:
		response = client.get_object(Bucket=bucket, Key=object_key)
		data = response["Body"].read()
		local_path.write_bytes(data)
		logger.info("Download succeeded for key '%s' to '%s'", object_key, local_path)
		return str(local_path)
	except ClientError as exc:
		logger.error("Download failed for '%s': %s", object_key, exc)
		return None


def list_buckets(verify_ssl: bool = False) -> List[str]:
	"""Return all bucket names visible to the configured credentials."""
	client = create_s3_client(verify_ssl=verify_ssl)
	try:
		response = client.list_buckets()
		bucket_names = [item["Name"] for item in response.get("Buckets", [])]
		logger.info("Found %d bucket(s)", len(bucket_names))
		return bucket_names
	except ClientError as exc:
		logger.error("Listing buckets failed: %s", exc)
		return []


def list_files(
	bucket_name: Optional[str] = None,
	prefix: Optional[str] = None,
	verify_ssl: bool = False,
) -> List[str]:
	"""Return object keys in a bucket, optionally filtered by prefix."""
	client = create_s3_client(verify_ssl=verify_ssl)
	target_bucket = bucket_name or bucket
	keys: List[str] = []
	params: Dict[str, Any] = {"Bucket": target_bucket}
	if prefix:
		params["Prefix"] = prefix

	try:
		paginator = client.get_paginator("list_objects_v2")
		for page in paginator.paginate(**params):
			for item in page.get("Contents", []):
				keys.append(item["Key"])
		logger.info("Found %d file(s) in bucket '%s'", len(keys), target_bucket)
		return keys
	except ClientError as exc:
		logger.error("Listing files failed for bucket '%s': %s", target_bucket, exc)
		return []


def list_file_metadata(
	bucket_name: Optional[str] = None,
	prefix: Optional[str] = None,
	verify_ssl: bool = False,
) -> List[Dict[str, Any]]:
	"""Return metadata for objects in a bucket, optionally filtered by prefix."""
	client = create_s3_client(verify_ssl=verify_ssl)
	target_bucket = bucket_name or bucket
	metadata_list: List[Dict[str, Any]] = []

	for key in list_files(bucket_name=target_bucket, prefix=prefix, verify_ssl=verify_ssl):
		try:
			head = client.head_object(Bucket=target_bucket, Key=key)
			metadata_list.append(
				{
					"Key": key,
					"Size": head.get("ContentLength"),
					"LastModified": str(head.get("LastModified")),
					"ETag": head.get("ETag"),
					"ContentType": head.get("ContentType"),
					"Metadata": head.get("Metadata", {}),
				}
			)
		except ClientError as exc:
			logger.error("Metadata read failed for '%s' in bucket '%s': %s", key, target_bucket, exc)

	logger.info("Collected metadata for %d file(s) in bucket '%s'", len(metadata_list), target_bucket)
	return metadata_list


def delete_file(
	object_key: str,
	bucket_name: Optional[str] = None,
	verify_ssl: bool = False,
) -> bool:
	"""Delete an existing object from a bucket. Returns False when key is missing."""
	client = create_s3_client(verify_ssl=verify_ssl)
	target_bucket = bucket_name or bucket

	try:
		# S3 delete_object is idempotent and may return success for missing keys.
		# Check object existence first so the return value reflects real deletion.
		client.head_object(Bucket=target_bucket, Key=object_key)
	except ClientError as exc:
		error_code = exc.response.get("Error", {}).get("Code", "")
		if error_code in {"NoSuchKey", "NotFound", "404"}:
			logger.info("Delete skipped, object not found: '%s' in bucket '%s'", object_key, target_bucket)
			return False
		logger.error("Delete pre-check failed for '%s' in bucket '%s': %s", object_key, target_bucket, exc)
		return False

	try:
		client.delete_object(Bucket=target_bucket, Key=object_key)
		logger.info("Deleted key '%s' from bucket '%s'", object_key, target_bucket)
		return True
	except ClientError as exc:
		logger.error("Delete failed for '%s' in bucket '%s': %s", object_key, target_bucket, exc)
		return False


if __name__ == "__main__":
	args = parse_cli_args()
	source_file = args.source_file
	bucket = args.bucket
	logger.info("Using bucket: %s", bucket)
	logger.info("Using source file: %s", source_file)
	logger.info("create_bucket result: %s", create_bucket())
	logger.info("upload_file result: %s", upload_file(source_file))
	logger.info("test_simple_download result: %s", test_simple_download(source_file))

	bucket_list = list_buckets()
	logger.info("list_buckets result: %s", bucket_list)

	file_list = list_files()
	logger.info("list_files result: %s", file_list)

	file_metadata = list_file_metadata()
	logger.info("list_file_metadata count: %d", len(file_metadata))
	if file_metadata:
		logger.info("list_file_metadata first item: %s", file_metadata[0])

	logger.info("delete_file result: %s", delete_file(source_file))
