export interface ParsedSearchQuery {
  filters: Array<{ field: string; value: string }>;
  terms: string[];
  groups: Array<{
    filters: Array<{ field: string; value: string }>;
    terms: string[];
  }>;
}

type ParsedSearchGroup = ParsedSearchQuery['groups'][number];

const LOGICAL_OPERATORS = new Set(['and', 'or']);

function isLogicalOperator(token: string) {
  return LOGICAL_OPERATORS.has(token.toLowerCase());
}

function isValidFieldName(field: string) {
  return /^[A-Za-z_][\w.-]*$/.test(field);
}

export function tokenizeSearchQuery(query: string): string[] {
  const tokens: string[] = [];
  let index = 0;

  const readQuoted = (quote: string) => {
    index += 1;
    let value = '';

    while (index < query.length) {
      const char = query[index];
      if (char === '\\' && index + 1 < query.length) {
        value += query[index + 1];
        index += 2;
        continue;
      }
      if (char === quote) {
        index += 1;
        break;
      }
      value += char;
      index += 1;
    }

    return value;
  };

  while (index < query.length) {
    while (/\s/.test(query[index] || '')) index += 1;
    if (index >= query.length) break;

    const firstChar = query[index];
    if (firstChar === '"' || firstChar === "'") {
      const quotedToken = readQuoted(firstChar).trim();
      if (quotedToken) tokens.push(quotedToken);
      continue;
    }

    let token = '';
    while (index < query.length && !/\s/.test(query[index])) {
      const char = query[index];
      if (char === '"' || char === "'") {
        token += readQuoted(char);
        continue;
      }
      token += char;
      index += 1;
    }

    const normalized = token.trim();
    if (normalized) tokens.push(normalized);
  }

  return tokens;
}

export function parseSearchQuery(query: string): ParsedSearchQuery {
  const parsed: ParsedSearchQuery = { filters: [], terms: [], groups: [] };
  let currentGroup: ParsedSearchGroup = { filters: [], terms: [] };

  const addGroup = () => {
    if (currentGroup.filters.length > 0 || currentGroup.terms.length > 0) {
      parsed.groups.push(currentGroup);
      currentGroup = { filters: [], terms: [] };
    }
  };

  const addFilter = (field: string, value: string) => {
    const filter = { field, value };
    parsed.filters.push(filter);
    currentGroup.filters.push(filter);
  };

  const addTerm = (term: string) => {
    parsed.terms.push(term);
    currentGroup.terms.push(term);
  };

  const tokens = tokenizeSearchQuery(query);
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    const lowerToken = token.toLowerCase();
    if (lowerToken === 'and') continue;
    if (lowerToken === 'or') {
      addGroup();
      continue;
    }

    if (token.endsWith(':')) {
      const field = token.slice(0, -1).trim();
      const nextToken = tokens[i + 1];
      if (field && isValidFieldName(field) && nextToken && !isLogicalOperator(nextToken)) {
        addFilter(field, nextToken);
        i += 1;
        continue;
      }
    }

    const separatorIndex = token.indexOf(':');
    if (separatorIndex > 0 && separatorIndex < token.length - 1) {
      const field = token.slice(0, separatorIndex).trim();
      const value = token.slice(separatorIndex + 1).trim();

      if (isValidFieldName(field) && value) {
        addFilter(field, value);
        continue;
      }
    }

    addTerm(token);
  }

  addGroup();

  return parsed;
}

export function getSearchHighlightTerms(query: string): string[] {
  const parsed = parseSearchQuery(query);
  const deduped = new Map<string, string>();

  [...parsed.terms, ...parsed.filters.map((filter) => filter.value)].forEach((term) => {
    const normalized = term.trim();
    if (!normalized) return;
    deduped.set(normalized.toLowerCase(), normalized);
  });

  return Array.from(deduped.values()).sort((a, b) => b.length - a.length);
}
