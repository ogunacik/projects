/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LogRecord } from '../types';
import JSZip from 'jszip';

export type S3DownloadMeta = {
  endpointUrl: string;
  publicEndpointUrl?: string;
  bucketName: string;
  forcePathStyle?: boolean;
};

/**
 * Triggers a web browser download of a text blob
 */
export function downloadBlob(content: string | Blob, filename: string, contentType: string) {
  const blob = content instanceof Blob ? content : new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function trimSlash(value: string): string {
  return String(value || '').trim().replace(/\/+$/, '');
}

function originKey(urlLike: string): string | null {
  try {
    const parsed = new URL(urlLike);
    return `${parsed.protocol}//${parsed.host}`.toLowerCase();
  } catch {
    return null;
  }
}

/** Endpoint bases used to recognize stored S3 object URLs. */
export function getS3EndpointBases(meta?: Partial<S3DownloadMeta> | null): string[] {
  if (!meta) return [];
  return [meta.endpointUrl, meta.publicEndpointUrl]
    .map((value) => trimSlash(String(value || '')))
    .filter(Boolean);
}

export function isS3ObjectUrl(url: string, meta?: Partial<S3DownloadMeta> | null): boolean {
  const raw = String(url || '').trim();
  if (!raw) return false;

  try {
    const parsed = new URL(raw, typeof window !== 'undefined' ? window.location.origin : 'https://placeholder.local');
    if (parsed.pathname.includes('/api/s3/proxy-download') || parsed.searchParams.has('key')) {
      return true;
    }

    const bases = getS3EndpointBases(meta);
    const urlOrigin = `${parsed.protocol}//${parsed.host}`.toLowerCase();
    if (bases.some((base) => originKey(base) === urlOrigin)) {
      return true;
    }

    const bucket = String(meta?.bucketName || '').trim().replace(/^\/+|\/+$/g, '');
    if (bucket) {
      const path = decodeURIComponent(parsed.pathname.replace(/^\/+/, ''));
      if (path === bucket || path.startsWith(`${bucket}/`)) return true;
      if (parsed.hostname.toLowerCase().startsWith(`${bucket.toLowerCase()}.`)) return true;
    }
  } catch {
    if (/[?&]key=/.test(raw) || raw.includes('/api/s3/proxy-download')) return true;
  }

  return false;
}

/** Extract object key from proxy links or path-/virtual-hosted-style S3 URLs. */
export function extractS3ObjectKeyFromUrl(
  downloadUrl: string,
  meta?: Partial<S3DownloadMeta> | null
): string | null {
  const raw = String(downloadUrl || '').trim();
  if (!raw) return null;

  try {
    const parsed = new URL(raw, typeof window !== 'undefined' ? window.location.origin : 'https://placeholder.local');
    const keyParam = parsed.searchParams.get('key');
    if (keyParam) return decodeURIComponent(keyParam);

    const path = decodeURIComponent(parsed.pathname.replace(/^\/+/, ''));
    if (!path || path.startsWith('api/s3/')) return null;

    const bucket = String(meta?.bucketName || '').trim().replace(/^\/+|\/+$/g, '');
    if (bucket && (path === bucket || path.startsWith(`${bucket}/`))) {
      return path.slice(bucket.length).replace(/^\/+/, '') || null;
    }

    if (bucket && parsed.hostname.toLowerCase().startsWith(`${bucket.toLowerCase()}.`)) {
      return path || null;
    }

    // Path-style without configured bucket: drop first segment when URL matches a known S3 endpoint.
    if (isS3ObjectUrl(raw, meta)) {
      const segments = path.split('/').filter(Boolean);
      if (segments.length >= 2) return segments.slice(1).join('/');
      if (segments.length === 1) return segments[0];
    }
  } catch {
    const match = raw.match(/[?&]key=([^&]+)/);
    if (match) return decodeURIComponent(match[1]);
  }

  return null;
}

/** Resolve the MinIO/S3 object key from an Elasticsearch document */
export function getS3KeyFromRecord(
  record: LogRecord,
  meta?: Partial<S3DownloadMeta> | null
): string | null {
  if (record.s3_key) return record.s3_key;
  if (record.download_url) {
    const fromUrl = extractS3ObjectKeyFromUrl(record.download_url, meta);
    if (fromUrl) return fromUrl;
  }
  if (record.archive_name) return record.archive_name;
  return null;
}

/** Convert an S3 object URL (or record) into the app's authenticated proxy download URL. */
export function toS3ProxyDownloadUrl(
  urlOrRecord: string | LogRecord,
  meta?: Partial<S3DownloadMeta> | null
): string | null {
  if (typeof urlOrRecord === 'string') {
    const raw = urlOrRecord.trim();
    if (!raw) return null;
    if (!isS3ObjectUrl(raw, meta) && !raw.includes('/api/s3/proxy-download') && !/[?&]key=/.test(raw)) {
      return null;
    }
    const key = extractS3ObjectKeyFromUrl(raw, meta);
    return key ? `/api/s3/proxy-download?key=${encodeURIComponent(key)}` : null;
  }

  const key = getS3KeyFromRecord(urlOrRecord, meta);
  return key ? `/api/s3/proxy-download?key=${encodeURIComponent(key)}` : null;
}

/**
 * Download actual S3/MinIO zip archives for selected rows (server bundles them)
 */
export async function downloadS3ArchivesBulk(
  records: LogRecord[],
  username?: string,
  meta?: Partial<S3DownloadMeta> | null
): Promise<{ success: boolean; error?: string }> {
  if (records.length === 0) {
    return { success: false, error: 'Select at least one document to download.' };
  }

  const keys = [
    ...new Set(
      records.map((record) => getS3KeyFromRecord(record, meta)).filter((k): k is string => Boolean(k))
    ),
  ];

  if (keys.length === 0) {
    console.warn('No S3 keys found on selected documents');
    return { success: false, error: 'Selected rows are missing s3_key, download_url, and archive_name.' };
  }

  try {
    const res = await fetch('/api/s3/bulk-download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ keys, username }),
    });

    if (!res.ok) {
      const body = await res.text();
      let message = body || `S3 bulk download failed with HTTP ${res.status}.`;
      try {
        const parsed = JSON.parse(body);
        message = parsed.error || parsed.message || message;
      } catch {}
      console.error('S3 bulk download failed:', message);
      return { success: false, error: message };
    }

    const blob = await res.blob();
    const timestampStr = new Date().toISOString().slice(0, 10);
    downloadBlob(blob, `s3_archives_${timestampStr}.zip`, 'application/zip');
    return { success: true };
  } catch (err) {
    console.error('S3 bulk download request failed:', err);
    return {
      success: false,
      error: err instanceof Error ? err.message : 'S3 bulk download request failed.',
    };
  }
}

/**
 * Convert selected Log records to CSV
 */
export function convertToCSV(records: LogRecord[]): string {
  if (records.length === 0) return '';

  const headers = [
    'id',
    'index',
    'timestamp',
    'level',
    'method',
    'status',
    'request_path',
    'ip',
    'bytes',
    'country',
    'user_agent',
    'archive_name',
    's3_key',
    'download_url',
    'description',
  ];

  const csvRows = [headers.join(',')];

  for (const record of records) {
    const values = [
      record._id,
      record._index,
      record.timestamp,
      record.level,
      record.method,
      record.status,
      record.request_path,
      `"${record.ip}"`,
      record.bytes,
      record.country,
      `"${record.user_agent.replace(/"/g, '""')}"`,
      record.archive_name,
      record.s3_key ?? '',
      `"${record.download_url}"`,
      `"${(record.description ?? '').replace(/"/g, '""')}"`,
    ];
    csvRows.push(values.join(','));
  }

  return csvRows.join('\n');
}

/**
 * Convert selected logs to JSON representation
 */
export function convertToJSON(records: LogRecord[]): string {
  return JSON.stringify(records, null, 2);
}

/**
 * Export Elasticsearch document metadata (not S3 payloads) as a ZIP
 */
export async function exportElasticsearchDocumentsZip(
  records: LogRecord[],
  zipFilename: string
): Promise<boolean> {
  if (records.length === 0) return false;

  const zip = new JSZip();

  const meta = {
    exportedAt: new Date().toISOString(),
    totalDocuments: records.length,
    indicesIncluded: Array.from(new Set(records.map((r) => r._index))),
    records: records.map((r) => ({
      id: r._id,
      index: r._index,
      archiveName: r.archive_name,
      s3_key: r.s3_key,
      download_url: r.download_url,
    })),
  };
  zip.file('export_manifest.json', JSON.stringify(meta, null, 2));
  zip.file('all_records.csv', convertToCSV(records));
  zip.file('all_records.json', convertToJSON(records));

  const docsFolder = zip.folder('documents');
  if (docsFolder) {
    for (const record of records) {
      docsFolder.file(`${record._id}.json`, JSON.stringify(record, null, 2));
    }
  }

  try {
    const content = await zip.generateAsync({ type: 'blob' });
    downloadBlob(content, zipFilename, 'application/zip');
    return true;
  } catch (err) {
    console.error('Failed to generate ES export ZIP:', err);
    return false;
  }
}