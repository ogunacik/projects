/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User } from '../types';

export function isAdminUser(user: User | null | undefined): boolean {
  if (!user) return false;
  return user.role === 'super_admin';
}
