/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Fragment, type ReactNode } from 'react';
import { Download, FileSpreadsheet, FileText } from 'lucide-react';
import { LogRecord } from '../types';
import { convertToCSV, downloadBlob } from '../utils/downloader';

interface DocumentDetailsViewProps {
  record: LogRecord;
  downloadUrl?: string | null;
  downloadLabel?: string | null;
  highlightTerms?: string[];
  className?: string;
  contentMaxHeightClass?: string;
  headerActions?: ReactNode;
  size?: 'compact' | 'large';
}

const hasDisplayValue = (value: unknown) => value != null && value !== '';

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export default function DocumentDetailsView({
  record,
  downloadUrl,
  downloadLabel,
  highlightTerms = [],
  className = '',
  contentMaxHeightClass = 'max-h-[70vh]',
  headerActions,
  size = 'compact',
}: DocumentDetailsViewProps) {
  const isLarge = size === 'large';
  const headerTextClass = isLarge ? 'text-sm' : 'text-xs';
  const actionTextClass = isLarge ? 'text-sm' : 'text-xs';
  const detailTextClass = isLarge ? 'text-sm' : 'text-xs';
  const jsonTextClass = isLarge ? 'text-sm' : 'text-[11px]';

  const renderHighlightedText = (value: unknown) => {
    const text = String(value ?? '');
    if (highlightTerms.length === 0 || text.length === 0) return text;

    const matcher = new RegExp(`(${highlightTerms.map(escapeRegExp).join('|')})`, 'gi');
    return text.split(matcher).map((part, index) => {
      if (!part) return null;
      const isMatch = highlightTerms.some((term) => term.toLowerCase() === part.toLowerCase());
      return isMatch ? (
        <mark key={`${part}-${index}`} className="rounded-sm bg-yellow-200 px-0.5 text-slate-950">
          {part}
        </mark>
      ) : (
        <Fragment key={`${part}-${index}`}>{part}</Fragment>
      );
    });
  };

  const getExportBaseName = () => {
    const index = record._index || 'document';
    const id = record._id || new Date().toISOString();
    return `document_${index}_${id}`.replace(/[^a-z0-9._-]+/gi, '_').slice(0, 160);
  };

  const handleExportCSV = () => {
    downloadBlob(convertToCSV([record]), `${getExportBaseName()}.csv`, 'text/csv');
  };

  const handleExportJSON = () => {
    downloadBlob(JSON.stringify(record, null, 2), `${getExportBaseName()}.json`, 'application/json');
  };

  return (
    <div className={`bg-white border border-slate-200 rounded-md shadow-inner flex flex-col p-4 gap-4 ${className}`}>
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <span className={`${headerTextClass} font-bold text-slate-700 flex items-center gap-1.5 font-sans`}>
          <FileText className="w-4 h-4 text-[#006bb4]" />
          JSON Document _source Details for record <span className="font-mono text-blue-700">{record._id}</span>
        </span>

        <div className="flex flex-wrap items-center gap-2">
          {headerActions}

          <button
            onClick={handleExportCSV}
            className={`${actionTextClass} text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors cursor-pointer`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Export CSV
          </button>

          <button
            onClick={handleExportJSON}
            className={`${actionTextClass} text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors cursor-pointer`}
          >
            <FileText className="w-3.5 h-3.5" /> Export JSON
          </button>

          {downloadUrl && (
            <a
              href={downloadUrl}
              download
              className={`${actionTextClass} text-white bg-slate-800 hover:bg-slate-900 px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors cursor-pointer`}
            >
              <Download className="w-3.5 h-3.5" /> {downloadLabel || 'Download the file'}
            </a>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className={`border border-slate-150 rounded bg-slate-50/20 ${contentMaxHeightClass} overflow-y-auto`}>
          <div className={`divide-y divide-slate-150 ${detailTextClass}`}>
            {Object.entries(record).filter(([, val]) => hasDisplayValue(val)).map(([key, val]) => (
              <div key={key} className="flex px-3 py-1.5 hover:bg-slate-50">
                <span className={`${isLarge ? 'w-44' : 'w-32'} text-slate-500 font-semibold truncate shrink-0`}>{key}</span>
                <span className="text-slate-800 break-all select-all font-mono">
                  {renderHighlightedText(typeof val === 'object' ? JSON.stringify(val) : String(val))}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className={`bg-slate-900 rounded p-3 text-slate-300 font-mono ${jsonTextClass} ${contentMaxHeightClass} overflow-y-auto border border-slate-950`}>
          <pre className="whitespace-pre">{renderHighlightedText(JSON.stringify(record, null, 2))}</pre>
        </div>
      </div>
    </div>
  );
}
