/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, Fragment, useMemo, useEffect, type MouseEvent as ReactMouseEvent } from 'react';
import {
  ChevronDown,
  ChevronRight,
  Download,
  ExternalLink,
  FileText,
  Terminal,
  Archive,
  FileSpreadsheet,
  AlertCircle,
  ArrowUpDown,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { LogRecord, LinkRule } from '../types';
import { toS3ProxyDownloadUrl, type S3DownloadMeta } from '../utils/downloader';
import { getSearchHighlightTerms } from '../utils/searchQuery';
import DocumentDetailsView from './DocumentDetailsView';

const COLUMN_WIDTH_STORAGE_KEY = 'releaselogs_manual_column_widths_compact_v2';
const MIN_COLUMN_WIDTH = 48;
const MAX_COLUMN_WIDTH = 560;
const CHARACTER_WIDTH_PX = 6.2;
const CELL_PADDING_PX = 22;
const ROW_ACTIONS_COLUMN_WIDTH = 54;
const CHECKBOX_COLUMN_WIDTH = 30;

interface CustomDocsTableProps {
  records: LogRecord[];
  visibleColumns: string[];
  linkRules: LinkRule[];
  s3DownloadMeta?: S3DownloadMeta | null;
  queryText: string;
  onAddSearchPhrase: (phrase: string) => void;
  selectedRowIds: Set<string>;
  onToggleRowSelection: (id: string) => void;
  onToggleAllRowsSelection: (currentPageIds: string[]) => void;
  onClearAllSelections: () => void;
  onExportEsZip: () => void;
  onDownloadS3Zip: () => void;
  onExportCSV: () => void;
  onExportJSON: () => void;
  isBulkDownloadRuleEnabled: boolean;
  selectedDownloadableCount: number;
  totalRecords?: number;
  currentPage?: number;
  rowsPerPage?: number;
  onPageChange?: (page: number) => void;
  onRowsPerPageChange?: (rowsPerPage: number) => void;
}

const clampColumnWidth = (width: number) => Math.max(MIN_COLUMN_WIDTH, Math.min(MAX_COLUMN_WIDTH, Math.ceil(width)));

const stringifyCellValue = (value: unknown) => {
  if (value == null) return '';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
};

const hasDisplayValue = (value: unknown) => value != null && value !== '';

const getLinkRuleTag = (rule?: LinkRule) => String(rule?.tag || 'downloadable').trim().toLowerCase();

const formatTableTimestamp = (value: string) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  const twoDigit = (part: number) => String(part).padStart(2, '0');
  return [
    twoDigit(date.getDate()),
    twoDigit(date.getMonth() + 1),
    date.getFullYear(),
  ].join('.') + `, ${twoDigit(date.getHours())}:${twoDigit(date.getMinutes())}:${twoDigit(date.getSeconds())}`;
};

const getDisplayValue = (record: LogRecord, column: string) => {
  if (column === 'timestamp') {
    return formatTableTimestamp(record.timestamp);
  }
  return stringifyCellValue((record as unknown as Record<string, unknown>)[column]);
};

const getLongestTextLength = (text: string) => {
  return text.split(/\r?\n/).reduce((longest, line) => Math.max(longest, line.length), 0);
};

const estimateColumnWidth = (label: string, values: string[], minWidth = MIN_COLUMN_WIDTH) => {
  const longest = values.reduce(
    (maxLength, value) => Math.max(maxLength, getLongestTextLength(value)),
    label.length
  );
  return Math.max(minWidth, clampColumnWidth(longest * CHARACTER_WIDTH_PX + CELL_PADDING_PX));
};

const readManualColumnWidths = () => {
  try {
    const parsed = JSON.parse(localStorage.getItem(COLUMN_WIDTH_STORAGE_KEY) || '{}') as Record<string, unknown>;
    return Object.fromEntries(
      Object.entries(parsed).filter((entry): entry is [string, number] => typeof entry[1] === 'number')
    );
  } catch {
    return {};
  }
};

const saveManualColumnWidths = (widths: Record<string, number>) => {
  try {
    localStorage.setItem(COLUMN_WIDTH_STORAGE_KEY, JSON.stringify(widths));
  } catch {
    // Keep resizing available even when localStorage is unavailable.
  }
};

export default function CustomDocsTable({
  records,
  visibleColumns,
  linkRules,
  s3DownloadMeta = null,
  queryText,
  onAddSearchPhrase,
  selectedRowIds,
  onToggleRowSelection,
  onToggleAllRowsSelection,
  onClearAllSelections,
  onExportEsZip,
  onDownloadS3Zip,
  onExportCSV,
  onExportJSON,
  isBulkDownloadRuleEnabled,
  selectedDownloadableCount,
  totalRecords,
  currentPage: controlledCurrentPage,
  rowsPerPage: controlledRowsPerPage,
  onPageChange,
  onRowsPerPageChange,
}: CustomDocsTableProps) {
  // Pagination State
  const [internalCurrentPage, setInternalCurrentPage] = useState(1);
  const [internalRowsPerPage, setInternalRowsPerPage] = useState(25);
  const [manualColumnWidths, setManualColumnWidths] = useState<Record<string, number>>(readManualColumnWidths);
  const [sortConfig, setSortConfig] = useState<{ column: string; direction: 'asc' | 'desc' } | null>(null);
  const isServerPaginated = typeof totalRecords === 'number' && Boolean(onPageChange) && Boolean(onRowsPerPageChange);
  const currentPage = controlledCurrentPage ?? internalCurrentPage;
  const rowsPerPage = controlledRowsPerPage ?? internalRowsPerPage;
  const setPage = onPageChange ?? setInternalCurrentPage;
  const hasDownloadableRule = useMemo(
    () => linkRules.some((rule) => rule.columnName === 'download_url' && ['downloadable', 's3_proxy'].includes(getLinkRuleTag(rule))),
    [linkRules]
  );

  // Expanded Docs for Row details drawer
  const [expandedDocIds, setExpandedDocIds] = useState<Set<string>>(new Set());

  const highlightTerms = useMemo(() => getSearchHighlightTerms(queryText), [queryText]);

  const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const renderHighlightedText = (value: unknown) => {
    const text = String(value ?? '');
    if (highlightTerms.length === 0 || text.length === 0) return text;

    const matcher = new RegExp(`(${highlightTerms.map(escapeRegExp).join('|')})`, 'gi');
    return text.split(matcher).map((part, index) => {
      if (!part) return null;
      const isMatch = highlightTerms.some((term) => term.toLowerCase() === part.toLowerCase());
      return isMatch ? (
        <mark key={`${part}-${index}`} className="rounded-sm bg-yellow-200 px-0.5 text-slate-950">
          {part}
        </mark>
      ) : (
        <Fragment key={`${part}-${index}`}>{part}</Fragment>
      );
    });
  };

  const toggleExpandDoc = (id: string) => {
    const next = new Set(expandedDocIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setExpandedDocIds(next);
  };

  const getSortValue = (record: LogRecord, column: string) => {
    return column === 'timestamp' ? record.timestamp : (record as unknown as Record<string, unknown>)[column];
  };

  const getComparableValue = (value: unknown) => {
    if (value == null || value === '') return { type: 'empty', value: '' };
    if (value instanceof Date) return { type: 'date', value: value.getTime() };
    if (typeof value === 'number') return { type: 'number', value };
    if (typeof value === 'string') {
      const trimmed = value.trim();
      const numericValue = Number(trimmed);
      if (trimmed !== '' && Number.isFinite(numericValue)) return { type: 'number', value: numericValue };
      const timestamp = Date.parse(trimmed);
      if (!Number.isNaN(timestamp) && /\d{4}-\d{2}-\d{2}|T\d{2}:\d{2}|:\d{2}/.test(trimmed)) {
        return { type: 'date', value: timestamp };
      }
      return { type: 'text', value: trimmed.toLowerCase() };
    }
    return { type: 'text', value: String(value).toLowerCase() };
  };

  const sortedRecords = useMemo(() => {
    if (!sortConfig) return records;
    return [...records].sort((a, b) => {
      const aComparable = getComparableValue(getSortValue(a, sortConfig.column));
      const bComparable = getComparableValue(getSortValue(b, sortConfig.column));

      if (aComparable.type === 'empty' && bComparable.type !== 'empty') return 1;
      if (bComparable.type === 'empty' && aComparable.type !== 'empty') return -1;

      let result = 0;
      if (
        (aComparable.type === 'number' || aComparable.type === 'date') &&
        aComparable.type === bComparable.type
      ) {
        result = Number(aComparable.value) - Number(bComparable.value);
      } else {
        result = String(aComparable.value).localeCompare(String(bComparable.value));
      }
      return sortConfig.direction === 'asc' ? result : -result;
    });
  }, [records, sortConfig]);

  const handleSort = (column: string) => {
    setSortConfig((current) => {
      if (current?.column === column) {
        return { column, direction: current.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { column, direction: 'asc' };
    });
    setPage(1);
  };

  const renderSortIcon = (column: string) => {
    if (sortConfig?.column !== column) return <ArrowUpDown className="w-2.5 h-2.5 text-slate-400" />;
    return sortConfig.direction === 'asc'
      ? <ArrowUp className="w-2.5 h-2.5 text-[#006bb4]" />
      : <ArrowDown className="w-2.5 h-2.5 text-[#006bb4]" />;
  };

  const autoColumnWidths = useMemo(() => {
    const widths: Record<string, number> = {};

    visibleColumns.forEach((column) => {
      widths[column] = estimateColumnWidth(
        column === 'timestamp' ? 'Time' : column,
        records.map((record) => getDisplayValue(record, column)),
        column === 'timestamp' ? 132 : MIN_COLUMN_WIDTH
      );
    });

    return widths;
  }, [records, visibleColumns]);

  const getColumnWidth = (column: string) => manualColumnWidths[column] ?? autoColumnWidths[column] ?? MIN_COLUMN_WIDTH;
  const tableWidth = useMemo(() => (
    ROW_ACTIONS_COLUMN_WIDTH + CHECKBOX_COLUMN_WIDTH + visibleColumns.reduce((total, column) => total + getColumnWidth(column), 0)
  ), [autoColumnWidths, manualColumnWidths, visibleColumns]);

  const handleColumnResizeStart = (event: ReactMouseEvent<HTMLSpanElement>, column: string) => {
    event.preventDefault();
    event.stopPropagation();
    const startX = event.clientX;
    const startWidth = getColumnWidth(column);
    let latestWidth = startWidth;

    const handleMove = (moveEvent: MouseEvent) => {
      latestWidth = clampColumnWidth(startWidth + moveEvent.clientX - startX);
      setManualColumnWidths((current) => ({ ...current, [column]: latestWidth }));
    };

    const handleUp = () => {
      setManualColumnWidths((current) => {
        const next = { ...current, [column]: latestWidth };
        saveManualColumnWidths(next);
        return next;
      });
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleUp);
    };

    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleUp);
  };

  const renderSortableHeader = (column: string, label = column, className = '') => (
    <div className="relative h-full pr-1">
      <button
        type="button"
        onClick={() => handleSort(column)}
        className={`w-full flex items-center justify-between gap-1 text-left hover:text-[#006bb4] cursor-pointer ${className}`}
        title={`Sort by ${label}`}
      >
        <span className="truncate">{label}</span>
        {renderSortIcon(column)}
      </button>
      <span
        onMouseDown={(event) => handleColumnResizeStart(event, column)}
        className="absolute -right-2 top-[-6px] h-7 w-2 cursor-col-resize border-r border-transparent hover:border-[#006bb4]"
        title={`Resize ${label}`}
      />
    </div>
  );

  // Pagination calculation
  const totalRecordCount = isServerPaginated ? (totalRecords || 0) : sortedRecords.length;
  const totalPages = Math.ceil(totalRecordCount / rowsPerPage) || 1;
  const startIndex = (currentPage - 1) * rowsPerPage;
  const paginatedRecords = isServerPaginated ? sortedRecords : sortedRecords.slice(startIndex, startIndex + rowsPerPage);
  const currentPageIds = paginatedRecords.map(r => r._id);

  useEffect(() => {
    const nextPage = Math.min(Math.max(1, currentPage), totalPages);
    if (nextPage !== currentPage) setPage(nextPage);
  }, [currentPage, setPage, totalPages]);

  // Is every item on current page selected?
  const isAllPageSelected = currentPageIds.length > 0 && currentPageIds.every(id => selectedRowIds.has(id));
  const hasSelectedRows = selectedRowIds.size > 0;
  const canBulkDownloadFiles = isBulkDownloadRuleEnabled && selectedDownloadableCount > 0;
  const selectedActionSummary = !hasSelectedRows
    ? 'Select rows to enable actions'
    : selectedDownloadableCount > 0
      ? `${selectedRowIds.size} selected, ${selectedDownloadableCount} file${selectedDownloadableCount === 1 ? '' : 's'} ready`
      : `${selectedRowIds.size} selected, no files found`;

  const pageOptions = useMemo(() => {
    return Array.from({ length: totalPages }, (_, index) => index + 1);
  }, [totalPages]);

  const handleRowsPerPageChange = (nextRowsPerPage: number) => {
    if (onRowsPerPageChange) {
      onRowsPerPageChange(nextRowsPerPage);
    } else {
      setInternalRowsPerPage(nextRowsPerPage);
      setInternalCurrentPage(1);
    }
  };

  /**
   * Evaluates customizable URL templates replacing {value} mapping
   */
  const renderParameterizedCell = (columnName: string, value: any, record: LogRecord) => {
    const rule = linkRules.find(r => r.columnName === columnName);
    if (!hasDisplayValue(value)) {
      return <span className="text-slate-300">-</span>;
    }

    if (rule) {
      const valStr = String(value);
      const ruleTag = getLinkRuleTag(rule);
      const template = String(rule.urlTemplate || '').trim();
      const isRawValueTemplate = template === '' || template.toLowerCase() === '{value}';
      const isAbsoluteRawUrl = /^[a-z][a-z0-9+.-]*:\/\//i.test(valStr) || valStr.startsWith('//');
      const isDownloadLink = ruleTag === 'downloadable' || ruleTag === 's3_proxy';
      const isNavigableRawValue = !isRawValueTemplate || isAbsoluteRawUrl || isDownloadLink;
      const rawUrl = isRawValueTemplate
        ? (isNavigableRawValue ? valStr : undefined)
        : rule.urlTemplate.replace(/\{value\}/gi, encodeURIComponent(valStr));
      // s3_proxy-tagged rules download through the authenticated app proxy.
      const proxiedS3Url = ruleTag === 's3_proxy' && rawUrl
        ? toS3ProxyDownloadUrl(rawUrl, s3DownloadMeta)
        : null;
      const url = proxiedS3Url || rawUrl;
      let label = rule.labelTemplate.replace(/\{value\}/gi, valStr);

      const themeColors = {
        default: 'text-slate-700 bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-800',
        blue: 'text-blue-700 bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-900',
        emerald: 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-900',
        amber: 'text-amber-700 bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-900',
        indigo: 'text-indigo-700 bg-indigo-50 hover:bg-indigo-150 border-indigo-200 text-indigo-900',
        rose: 'text-rose-700 bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-900',
      };

      const colorClass = themeColors[rule.colorScheme] || themeColors.blue;

      // Wrap links into high-contrast tags to make them distinct and functional
      return (
        <a
          href={url}
          target={isDownloadLink ? "_self" : (rule.openInNewTab ? "_blank" : "_self")}
          rel="noopener noreferrer"
          onClick={(e) => {
            if (isRawValueTemplate && !isDownloadLink && !isAbsoluteRawUrl) {
              e.preventDefault();
            }
          }}
          download={isDownloadLink ? '' : undefined}
          className={`inline-flex items-center gap-1.5 px-2 py-1 rounded border text-xs font-mono leading-none transition-all duration-150 shadow-2xs ${colorClass}`}
          title={
            url
              ? (proxiedS3Url
                  ? `S3 object via proxy: ${rawUrl}`
                  : isDownloadLink
                    ? `Raw download URL: ${url}`
                    : `Dynamic link custom destination: ${url}`)
              : 'Raw link value is not an absolute URL'
          }
        >
          <span className="truncate max-w-[200px]">{renderHighlightedText(label)}</span>
          <ExternalLink className="w-2.5 h-2.5 opacity-60" />
        </a>
      );
    }

    if (columnName === 'timestamp') {
      return <span className="text-slate-600 font-sans font-medium text-[11px]">{renderHighlightedText(formatTableTimestamp(String(value)))}</span>;
    }

    // Default column rendering is simple text output
    return <span className="text-slate-750 font-mono text-[11px] leading-snug">{renderHighlightedText(value)}</span>;
  };

  const getSingleLogDownloadUrl = (record: LogRecord) => {
    const rule = linkRules.find((item) => item.columnName === 'download_url');
    const ruleTag = getLinkRuleTag(rule);

    if (ruleTag === 's3_proxy') {
      return (
        toS3ProxyDownloadUrl(record, s3DownloadMeta) ||
        (record.download_url ? toS3ProxyDownloadUrl(record.download_url, s3DownloadMeta) : null)
      );
    }

    return record.download_url || null;
  };

  const getSingleLogDownloadLabel = (record: LogRecord) => {
    const rule = linkRules.find((item) => item.columnName === 'download_url');
    if (!rule) return null;
    const value = String(record.download_url || record.s3_key || record._id || '');
    return String(rule.labelTemplate || '{value}').replace(/\{value\}/gi, value);
  };

  const getDocumentDetailsUrl = (record: LogRecord) => {
    const params = new URLSearchParams({
      index: record._index,
      id: record._id,
    });
    return `/discover/doc?${params.toString()}`;
  };

  const openDocumentDetailsWindow = (record: LogRecord) => {
    window.open(getDocumentDetailsUrl(record), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="flex-1 flex flex-col bg-white p-2 gap-2 text-[11px]" id="discover-datagrid">

      {/* Search Header Statistics & Page Info */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
          <Terminal className="w-3.5 h-3.5 text-slate-500" />
          <span>Index Documents Results ({totalRecordCount} hits)</span>
          <span className="text-slate-400 font-normal">|</span>
          <span className="font-mono text-[11px] text-slate-500">
            Showing logs {totalRecordCount > 0 ? startIndex + 1 : 0} to {Math.min(startIndex + paginatedRecords.length, totalRecordCount)} of {totalRecordCount}
          </span>
        </div>

        {/* Page Switcher */}
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
            Rows
            <select
              value={rowsPerPage}
              onChange={(event) => handleRowsPerPageChange(Number(event.target.value))}
              className="border border-slate-200 bg-white rounded px-2 py-1 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#006bb4]"
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
              <option value={250}>250</option>
            </select>
          </label>
          <button
            onClick={() => setPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className="px-2.5 py-1 text-xs border border-slate-200 rounded hover:bg-slate-50 disabled:opacity-50 font-medium transition-colors cursor-pointer"
          >
            ◀ Previous
          </button>
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
            Page
            <select
              value={currentPage}
              onChange={(event) => setPage(Number(event.target.value))}
              className="border border-slate-200 bg-white rounded px-2 py-1 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#006bb4] min-w-16"
            >
              {pageOptions.map((page) => (
                <option key={page} value={page}>{page}</option>
              ))}
            </select>
            <span className="font-mono text-slate-500">/ {totalPages}</span>
          </label>
          <button
            onClick={() => setPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            className="px-2.5 py-1 text-xs border border-slate-200 rounded hover:bg-slate-50 disabled:opacity-50 font-medium transition-colors cursor-pointer"
          >
            Next ▶
          </button>
        </div>
      </div>

      {/* Selected Row Documents panel */}
      <div className={`bg-slate-900 border border-slate-800 text-white rounded-lg p-3.5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3 anim-fade-in z-20 ${hasSelectedRows ? '' : 'opacity-80'}`} id="floating-actions">
          <div className="flex items-center gap-3">
            <span className={`flex items-center justify-center w-6 h-6 text-white rounded-full text-xs font-bold font-mono ${hasSelectedRows ? 'bg-[#006bb4]' : 'bg-slate-700'}`}>
              {selectedRowIds.size}
            </span>
            <div>
              <span className="text-xs font-semibold text-slate-100 block">
                Selected Row Documents
              </span>
              <span className={`text-[10px] font-mono block ${hasSelectedRows ? 'text-[#00a9e5]' : 'text-slate-500'}`}>
                {selectedActionSummary}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase tracking-wide hidden sm:inline">Selected actions</span>

            <button
              onClick={onDownloadS3Zip}
              disabled={!canBulkDownloadFiles}
              className="bg-[#006bb4] hover:bg-[#005a96] disabled:bg-slate-800 disabled:text-slate-500 disabled:border-slate-700 text-white text-xs font-semibold px-2.5 py-1.5 rounded border border-[#005a96] flex items-center gap-1.5 transition-colors cursor-pointer disabled:cursor-not-allowed"
              title={
                isBulkDownloadRuleEnabled
                  ? `Download ${selectedDownloadableCount} selected payload file(s) as one ZIP`
                  : 'Create a download_url link rule tagged s3_proxy to enable bulk file downloads'
              }
            >
              <Download className="w-3.5 h-3.5 text-sky-100 shrink-0" />
              Download Files ZIP
              {selectedDownloadableCount > 0 && (
                <span className="rounded bg-white/15 px-1.5 py-0.5 text-[10px] font-mono">
                  {selectedDownloadableCount}
                </span>
              )}
            </button>

            <button
              onClick={onExportEsZip}
              disabled={!hasSelectedRows}
              className="bg-slate-800 hover:bg-slate-700 disabled:bg-slate-850 disabled:text-slate-500 text-slate-200 text-xs font-semibold px-2.5 py-1.5 rounded border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer disabled:cursor-not-allowed"
              title="Export selected Elasticsearch documents as ZIP (JSON + CSV)"
            >
              <Archive className="w-3.5 h-3.5 text-violet-400 shrink-0" />
              Export Documents (ZIP)
            </button>

            <button
              onClick={onExportCSV}
              disabled={!hasSelectedRows}
              className="bg-slate-800 hover:bg-slate-700 disabled:bg-slate-850 disabled:text-slate-500 text-slate-200 text-xs font-semibold px-2.5 py-1.5 rounded border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer disabled:cursor-not-allowed"
              title="Export selected rows as CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              Export CSV
            </button>

            <button
              onClick={onExportJSON}
              disabled={!hasSelectedRows}
              className="bg-slate-800 hover:bg-slate-700 disabled:bg-slate-850 disabled:text-slate-500 text-slate-200 text-xs font-semibold px-2.5 py-1.5 rounded border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer disabled:cursor-not-allowed"
              title="Export selected rows as JSON"
            >
              <FileText className="w-3.5 h-3.5 text-orange-400 shrink-0" />
              Export JSON
            </button>

            <div className="h-6 w-px bg-slate-700 mx-1 hidden sm:block" />

            <button
              onClick={onClearAllSelections}
              disabled={!hasSelectedRows}
              className="text-xs hover:text-white text-slate-400 font-medium hover:underline px-2.5 py-1 transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:text-slate-400 disabled:hover:no-underline"
            >
              Deselect All
            </button>
          </div>
        </div>

      {/* Main Grid Table wrapper */}
      <div className="border border-slate-200 rounded-md overflow-hidden flex flex-col min-h-[300px] relative">
        <div className="overflow-x-auto overflow-y-visible">
          <table
            className="text-left border-collapse table-fixed select-text text-[11px]"
            style={{ width: tableWidth }}
          >
            <colgroup>
              <col style={{ width: ROW_ACTIONS_COLUMN_WIDTH }} />
              <col style={{ width: CHECKBOX_COLUMN_WIDTH }} />
              {visibleColumns.map((column) => (
                <col key={column} style={{ width: getColumnWidth(column) }} />
              ))}
            </colgroup>

            {/* Table Header Row */}
            <thead className="bg-slate-100 border-b border-slate-200 text-[10px] font-semibold text-slate-600 sticky top-0 z-10 shadow-3xs">
              <tr>
                {/* Row actions column */}
                <th className="py-1.5 px-0 text-center border-r border-slate-200"></th>

                {/* Global Row Selection */}
                <th className="py-1.5 px-0 text-center border-r border-[#e2e8f0]">
                  <input
                    type="checkbox"
                    checked={isAllPageSelected}
                    onChange={() => onToggleAllRowsSelection(currentPageIds)}
                    className="h-3 w-3 rounded border-slate-300 text-[#006bb4] focus:ring-[#006bb4] cursor-pointer"
                    title="Select/Deselect all rows on this page"
                  />
                </th>

                {/* Dynamically Toggled Columns */}
                {visibleColumns.map((column) => (
                  <th
                    key={column}
                    className="py-1.5 px-1.5 border-r border-slate-200 font-sans truncate"
                  >
                    {renderSortableHeader(column, column === 'timestamp' ? 'Time' : column)}
                  </th>
                ))}
              </tr>
            </thead>

            {/* Table Body Content */}
            <tbody className="divide-y divide-slate-150 text-[11px] font-mono leading-snug">
              {paginatedRecords.map((record) => {
                const isExpanded = expandedDocIds.has(record._id);
                const isSelected = selectedRowIds.has(record._id);

                return (
                  <Fragment key={record._id}>
                    <tr
                      key={record._id}
                      onDoubleClick={() => openDocumentDetailsWindow(record)}
                      className={`hover:bg-slate-50/75 transition-colors duration-75 cursor-default ${isSelected ? 'bg-blue-50/30' : ''}`}
                      title="Double-click to open document details in a separate window"
                    >
                      {/* Row details actions */}
                      <td className="py-1.5 px-1 text-center border-r border-slate-150">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => toggleExpandDoc(record._id)}
                            className="text-slate-500 hover:text-slate-800 transition-colors p-1 rounded hover:bg-slate-200 focus:outline-none cursor-pointer"
                            title={isExpanded ? 'Hide inline document details' : 'Show inline document details'}
                          >
                            {isExpanded ? (
                              <ChevronDown className="w-3.5 h-3.5 text-slate-700" />
                            ) : (
                              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                            )}
                          </button>
                          <button
                            onClick={() => openDocumentDetailsWindow(record)}
                            className="text-slate-400 hover:text-[#006bb4] transition-colors p-1 rounded hover:bg-blue-50 focus:outline-none cursor-pointer"
                            title="Open document details in a separate window"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                      {/* Row Checkbox Picker */}
                      <td className="py-1.5 text-center border-r border-slate-150">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => onToggleRowSelection(record._id)}
                          className="h-3 w-3 rounded border-slate-300 text-[#006bb4] focus:ring-[#006bb4] cursor-pointer"
                        />
                      </td>

                      {/* Dynamically configured variable index contents */}
                      {visibleColumns.map((column) => {
                        const cellValue = (record as Record<string, unknown>)[column];

                        return (
                          <td
                            key={column}
                            className="py-1.5 px-1.5 border-r border-slate-150 truncate"
                          >
                            {renderParameterizedCell(column, cellValue, record)}
                          </td>
                        );
                      })}
                    </tr>

                    {/* Expandable Document details Drawer mimicking Kibana metadata view */}
                    {isExpanded && (
                      <tr key={`expanded-${record._id}`} className="bg-slate-50/80">
                        <td colSpan={visibleColumns.length + 2} className="py-3 px-4 border-b border-slate-200">
                          <DocumentDetailsView
                            record={record}
                            downloadUrl={hasDownloadableRule ? getSingleLogDownloadUrl(record) : null}
                            downloadLabel={hasDownloadableRule ? getSingleLogDownloadLabel(record) : null}
                            highlightTerms={highlightTerms}
                            contentMaxHeightClass="max-h-72"
                            headerActions={
                              <button
                                onClick={() => openDocumentDetailsWindow(record)}
                                className="text-xs text-[#006bb4] bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <ExternalLink className="w-3.5 h-3.5" /> Open window
                              </button>
                            }
                          />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}

              {records.length === 0 && (
                <tr>
                  <td colSpan={visibleColumns.length + 2} className="py-12 text-center text-slate-450 text-xs">
                    <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    No documents matched search filters. Refine query text or adjust time picker intervals.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
