type MockArchive = {
  key: string;
  size: number;
  lastModified: string;
  contentType: string;
  description: string;
};

/** Mock zip objects uploaded to MinIO and indexed in Elasticsearch */
const BASE_S3_MOCK_ARCHIVES: MockArchive[] = [
  {
    key: 'snaps/daily-log-backup_2026-05-24.zip',
    size: 1450280,
    lastModified: '2026-05-24T18:00:10.000Z',
    contentType: 'application/zip',
    description: 'Daily HTTP access log snapshot — May 24',
  },
  {
    key: 'snaps/daily-log-backup_2026-05-25.zip',
    size: 1682124,
    lastModified: '2026-05-25T07:30:15.000Z',
    contentType: 'application/zip',
    description: 'Daily HTTP access log snapshot — May 25',
  },
  {
    key: 'snaps/weekly-aggregate_2026-w21.zip',
    size: 5242880,
    lastModified: '2026-05-25T12:00:00.000Z',
    contentType: 'application/zip',
    description: 'Weekly aggregated telemetry bundle (week 21)',
  },
  {
    key: 'archives/security-events_2026-05.zip',
    size: 892416,
    lastModified: '2026-05-20T09:15:00.000Z',
    contentType: 'application/zip',
    description: 'Security event archive — May 2026',
  },
  {
    key: 'archives/payment-gateway-dumps_2026-05-24.zip',
    size: 3145728,
    lastModified: '2026-05-24T23:59:59.000Z',
    contentType: 'application/zip',
    description: 'Payment gateway transaction dump',
  },
  {
    key: 'archives/api-traces_export_2026-05-26.zip',
    size: 2097152,
    lastModified: '2026-05-26T06:00:00.000Z',
    contentType: 'application/zip',
    description: 'API trace export for release validation',
  },
];

function generateAdditionalMockArchives(count: number): MockArchive[] {
  const services = [
    'auth-service',
    'billing-api',
    'checkout-worker',
    'customer-portal',
    'devops-agent',
    'fraud-engine',
    'gateway',
    'inventory-sync',
    'notification-hub',
    'payment-gateway',
    'release-orchestrator',
    'security-scanner',
  ];
  const categories = ['snaps', 'archives', 'traces', 'reports'];
  const contentTypes: Record<string, string> = {
    zip: 'application/zip',
    gz: 'application/gzip',
    json: 'application/json',
    pdf: 'application/pdf',
  };
  const baseTime = new Date('2026-05-29T08:00:00.000Z').getTime();

  return Array.from({ length: count }, (_, i) => {
    const service = services[i % services.length];
    const category = categories[i % categories.length];
    const extension = i % 10 === 0 ? 'json' : i % 15 === 0 ? 'pdf' : i % 4 === 0 ? 'gz' : 'zip';
    const day = String(1 + (i % 28)).padStart(2, '0');
    const sequence = String(i + 1).padStart(3, '0');
    const size = 256000 + (i + 1) * 73117;
    const timestamp = new Date(baseTime - i * 37 * 60 * 1000).toISOString();

    return {
      key: `${category}/${service}_release-evidence_2026-05-${day}_${sequence}.${extension}`,
      size,
      lastModified: timestamp,
      contentType: contentTypes[extension],
      description: `${service} release evidence bundle ${sequence}`,
    };
  });
}

export const S3_MOCK_ARCHIVES: MockArchive[] = [
  ...BASE_S3_MOCK_ARCHIVES,
  ...generateAdditionalMockArchives(114),
];

export interface S3ListedFile {
  key: string;
  size: number;
  lastModified: string;
  contentType: string;
}
