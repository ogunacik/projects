import fs from "fs";
import path from "path";
import * as yaml from "js-yaml";
import { Agent as UndiciAgent, type Dispatcher } from "undici";
import { generateMockLogs } from "./src/data/mockElasticData";

const CONFIG_PATH = process.env.CONFIG_PATH || path.join(process.cwd(), "config.yaml");

function loadAppConfig() {
  try {
    if (!fs.existsSync(CONFIG_PATH)) return null;
    const raw = fs.readFileSync(CONFIG_PATH, "utf8");
    return (yaml.load(raw) as any) || null;
  } catch (err) {
    return null;
  }
}

const APP_CONFIG = loadAppConfig();
const ES_URL = APP_CONFIG?.elasticsearch?.nodeUrls?.split(",")[0]?.trim() || "";
const ES_AUTH = (() => {
  if (!APP_CONFIG?.elasticsearch) return "";
  if (APP_CONFIG.elasticsearch.authMethod === "basic" && APP_CONFIG.elasticsearch.username && APP_CONFIG.elasticsearch.password) {
    return "Basic " + Buffer.from(`${APP_CONFIG.elasticsearch.username}:${APP_CONFIG.elasticsearch.password}`).toString("base64");
  }
  if (APP_CONFIG.elasticsearch.authMethod === "token" && APP_CONFIG.elasticsearch.token) {
    return `ApiKey ${APP_CONFIG.elasticsearch.token}`;
  }
  return "";
})();

function resolveConfigRelativePath(filePath: string) {
  if (!filePath) return "";
  const trimmed = filePath.trim();
  if (!trimmed) return "";
  if (path.isAbsolute(trimmed)) return trimmed;
  return path.resolve(path.dirname(CONFIG_PATH), trimmed);
}

function readPemValue(content?: string, filePath?: string, fileName?: string) {
  const inline = String(content || "").trim();
  if (inline) return inline;

  const configuredPath = String(filePath || "").trim();
  if (configuredPath) {
    const resolved = resolveConfigRelativePath(configuredPath);
    if (fs.existsSync(resolved)) return fs.readFileSync(resolved, "utf8");
  }

  const configuredName = String(fileName || "").trim();
  if (configuredName) {
    const fallback = resolveConfigRelativePath(path.join("tls", configuredName));
    if (fs.existsSync(fallback)) return fs.readFileSync(fallback, "utf8");
  }

  return undefined;
}

function createTlsOptions(config: any) {
  const rejectUnauthorized = config?.verifyServerCertificate ?? config?.verifyCertificates ?? true;
  const ca = readPemValue(config?.caCertificateContent, config?.caCertificatePath, config?.caCertificateName);
  const cert = readPemValue(config?.clientCertificateContent, config?.clientCertificatePath, config?.clientCertificateName);
  const key = readPemValue(config?.clientKeyContent, config?.clientKeyPath, config?.clientKeyName);
  return {
    rejectUnauthorized,
    ...(ca ? { ca } : {}),
    ...(cert ? { cert } : {}),
    ...(key ? { key } : {}),
  };
}

const esFetchDispatcher: Dispatcher | undefined =
  APP_CONFIG?.elasticsearch?.enableSSL || ES_URL.startsWith("https://")
    ? new UndiciAgent({ connect: createTlsOptions(APP_CONFIG.elasticsearch) })
    : undefined;

function esFetch(input: string, init: RequestInit = {}) {
  return fetch(input, {
    ...init,
    ...(esFetchDispatcher ? { dispatcher: esFetchDispatcher } : {}),
  } as RequestInit & { dispatcher?: Dispatcher });
}

async function configureKibanaSystemPassword() {
  const password = process.env.KIBANA_SYSTEM_PASSWORD?.trim();
  if (!password || !ES_AUTH) return;

  const response = await esFetch(`${ES_URL}/_security/user/kibana_system/_password`, {
    method: "POST",
    headers: {
      "Authorization": ES_AUTH,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ password }),
  });

  if (response.ok) {
    console.log("[ES-INIT-SERVICE] kibana_system password configured.");
  } else {
    const text = await response.text().catch(() => "");
    console.warn(`[ES-INIT-SERVICE] Could not configure kibana_system password: ${response.status} ${text.slice(0, 200)}`);
  }
}

function stripElasticsearchMetadata(doc: Record<string, unknown>) {
  const { _id, _index, _score, _type, ...source } = doc;
  return source;
}

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function runInitialization() {
  console.log(`[ES-INIT-SERVICE] Starting independent Elasticsearch initialization service...`);
  if (!ES_URL) {
    console.log(`[ES-INIT-SERVICE] Elasticsearch URL is not configured. Set elasticsearch.nodeUrls in config.yaml.`);
    return;
  }
  console.log(`[ES-INIT-SERVICE] Target URL: ${ES_URL}`);

  let isConnected = false;
  let retries = 30;

  // 1. Wait for Elasticsearch to become available and healthy (yellow/green)
  while (retries > 0 && !isConnected) {
    try {
      console.log(`[ES-INIT-SERVICE] Pinging Elasticsearch, ${retries} attempts remaining...`);
      const healthResponse = await esFetch(`${ES_URL}/_cluster/health`, {
        headers: { "Authorization": ES_AUTH }
      });

      if (healthResponse.ok) {
        const health = await healthResponse.json();
        if (health && (health.status === "green" || health.status === "yellow")) {
          console.log(`[ES-INIT-SERVICE] Connected successfully! Cluster status: ${health.status}`);
          isConnected = true;
          break;
        } else {
          console.warn(`[ES-INIT-SERVICE] Cluster is online but status is: ${health?.status || 'unknown'}`);
        }
      } else {
        console.warn(`[ES-INIT-SERVICE] Ping failed with status: ${healthResponse.status}`);
      }
    } catch (err: any) {
      console.warn(`[ES-INIT-SERVICE] Ping error: ${err?.message || err}`);
    }

    retries--;
    if (!isConnected && retries > 0) {
      await sleep(2000);
    }
  }

  if (!isConnected) {
    console.log(`[ES-INIT-SERVICE] Native Elasticsearch cluster not detected at ${ES_URL}. Fallback simulator active. Exiting initializer.`);
    process.exit(0);
  }

  await configureKibanaSystemPassword();

  // 2. Disable disk watermark routing blocks so our sandbox storage can safely write index documents
  try {
    console.log(`[ES-INIT-SERVICE] Tuning cluster disk watermark thresholds to avoid read-only locks...`);
    const sRes = await esFetch(`${ES_URL}/_cluster/settings`, {
      method: "PUT",
      headers: {
        "Authorization": ES_AUTH,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        persistent: {
          "cluster.routing.allocation.disk.threshold_enabled": false
        },
        transient: {
          "cluster.routing.allocation.disk.threshold_enabled": false
        }
      })
    }).then(r => r.json());
    console.log(`[ES-INIT-SERVICE] Cluster settings updated:`, JSON.stringify(sRes));
  } catch (err: any) {
    console.error(`[ES-INIT-SERVICE] Error updating cluster settings:`, err.message);
  }

  // 3. Clear any existing read-only flood-stage block triggers on nodes
  try {
    console.log(`[ES-INIT-SERVICE] Unblocking indexes (clearing read_only_allow_delete states)...`);
    const uRes = await esFetch(`${ES_URL}/_all/_settings`, {
      method: "PUT",
      headers: {
        "Authorization": ES_AUTH,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        "index.blocks.read_only_allow_delete": null
      })
    }).then(r => r.json());
    console.log(`[ES-INIT-SERVICE] Indexes unblocked:`, JSON.stringify(uRes));
  } catch (err: any) {
    console.error(`[ES-INIT-SERVICE] Error clearing index read-only blocks:`, err.message);
  }

  // 4. Seeding dynamic mock records into Elasticsearch
  try {
    const seedIndex =
      process.env.SEED_INDEX?.trim() ||
      APP_CONFIG?.discover?.defaultIndex?.trim() ||
      APP_CONFIG?.audit?.elasticsearchIndex?.trim() ||
      "";
    const seedLogs = seedIndex
      ? generateMockLogs(new Date().toISOString(), seedIndex, {
          endpointUrl: String(APP_CONFIG?.s3?.endpointUrl || "https://localhost:9000").trim(),
          bucketName: String(APP_CONFIG?.s3?.bucketName || "elastic-kibana-logs").trim(),
          forcePathStyle: APP_CONFIG?.s3?.forcePathStyle !== false,
        })
      : [];
    const allLogs = seedLogs;
    console.log(`[ES-INIT-SERVICE] Seed index: ${seedIndex || "(none)"}`);
    console.log(`[ES-INIT-SERVICE] Generated ${allLogs.length} documents across indices.`);

    let bulkBody = "";
    allLogs.forEach(log => {
      bulkBody += JSON.stringify({ index: { _index: log._index, _id: log._id } }) + "\n";
      bulkBody += JSON.stringify(stripElasticsearchMetadata(log as unknown as Record<string, unknown>)) + "\n";
    });

    console.log(`[ES-INIT-SERVICE] Sending bulk request to Elasticsearch (_bulk?refresh=true)...`);
    const bulkResponse = await esFetch(`${ES_URL}/_bulk?refresh=true`, {
      method: "POST",
      headers: {
        "Authorization": ES_AUTH,
        "Content-Type": "application/x-ndjson"
      },
      body: bulkBody
    });

    if (bulkResponse.ok) {
      const resultObj = await bulkResponse.json();
      if (resultObj && resultObj.errors) {
        console.error(`[ES-INIT-SERVICE] Bulk indexing completed with errors:`);
        const itemErrors = resultObj.items?.filter((it: any) => it.index && it.index.error);
        if (itemErrors && itemErrors.length > 0) {
          console.error(`First 5 error entries:`, JSON.stringify(itemErrors.slice(0, 5), null, 2));
        }
      } else {
        console.log(`[ES-INIT-SERVICE] SUCCESS: Seeded Elasticsearch with ${allLogs.length} logs!`);
      }

      // Single-node compose has no replicas; force green health for seeded indices.
      const seededIndices = [...new Set(allLogs.map((log) => log._index).filter(Boolean))];
      if (seededIndices.length > 0) {
        const replicaRes = await esFetch(`${ES_URL}/${seededIndices.map(encodeURIComponent).join(",")}/_settings`, {
          method: "PUT",
          headers: {
            "Authorization": ES_AUTH,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ index: { number_of_replicas: 0 } })
        });
        if (replicaRes.ok) {
          console.log(`[ES-INIT-SERVICE] Set number_of_replicas=0 on: ${seededIndices.join(", ")}`);
        } else {
          const text = await replicaRes.text().catch(() => "");
          console.warn(`[ES-INIT-SERVICE] Could not update replica settings: ${replicaRes.status} ${text.slice(0, 200)}`);
        }
      }
    } else {
      console.error(`[ES-INIT-SERVICE] ERROR: Bulk request failed with HTTP code ${bulkResponse.status}`);
      const errText = await bulkResponse.text().catch(() => "");
      console.error(`Error details: ${errText.slice(0, 500)}`);
    }

    // Double-check final index document counts
    console.log(`[ES-INIT-SERVICE] Fetching index document counts for verification...`);
    const finalCounts = await esFetch(`${ES_URL}/_cat/indices?format=json`, {
      headers: { "Authorization": ES_AUTH }
    }).then(r => r.json()).catch(() => null);

    if (finalCounts && Array.isArray(finalCounts)) {
      console.log(`[ES-INIT-SERVICE] Current Elasticsearch Indixes Status:`);
      finalCounts.forEach(it => {
        console.log(`  - Index: ${it.index} | docs.count: ${it["docs.count"]} | status: ${it.status} | health: ${it.health}`);
      });
    }

    console.log(`[ES-INIT-SERVICE] Service execution completed successfully. Lifecycle terminated.`);
    process.exit(0);
  } catch (err: any) {
    console.error(`[ES-INIT-SERVICE] Unhandled error during seeding:`, err.message);
    process.exit(1);
  }
}

runInitialization();
