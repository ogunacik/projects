/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LogRecord } from '../types';

const COUNTRIES = ['US', 'DE', 'FR', 'GB', 'JP', 'CA', 'AU', 'BR', 'KR', 'IN'];
const PATHS = [
  '/api/v1/auth/login',
  '/api/v1/users/profile',
  '/api/v1/products/list?category=cloud',
  '/api/v1/checkout/cart',
  '/api/v1/payment/charge',
  '/static/js/main.bc83ea2.js',
  '/index.html',
  '/images/hero-banner.webp',
  '/wp-admin/phpmyadmin/setup.php',
  '/api/v1/monitoring/healthz',
  '/api/v2/compute/deploy',
  '/api/v1/files/upload'
];
const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',
  'Go-http-client/1.1 (MetricsCollector)',
  'curl/8.4.0 (SecurityScan)',
  'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
];

const METHODS = ['GET', 'POST', 'PUT', 'DELETE'];

export function generateMockLogs(baseDateStr: string = '2026-05-25T02:12:49Z', targetIndex: string): LogRecord[] {
  const baseDate = new Date(baseDateStr);
  const logs: LogRecord[] = [];

  for (let i = 0; i < 220; i++) {
    const id = `doc_${Math.random().toString(36).substring(2, 11).toUpperCase()}`;
    const indexName = targetIndex;
    let path = PATHS[Math.floor(Math.random() * PATHS.length)];
    let method = METHODS[Math.floor(Math.random() * METHODS.length)];
    let status = 200;
    let level: 'info' | 'warn' | 'error' = 'info';

    const shapePicker = Math.random();
    if (shapePicker < 0.6) {
      const statusPicker = Math.random();
      if (statusPicker < 0.70) {
        status = 200;
        level = 'info';
      } else if (statusPicker < 0.85) {
        status = Math.random() < 0.5 ? 301 : 304;
        level = 'info';
      } else if (statusPicker < 0.95) {
        status = Math.random() < 0.6 ? 404 : 403;
        level = 'warn';
      } else {
        status = Math.random() < 0.7 ? 500 : 503;
        level = 'error';
      }
    } else if (shapePicker < 0.85) {
      path = Math.random() < 0.5 ? '/ssh/auth/failed' : '/ssh/auth/session_open';
      method = 'SSH';
      const levelPicker = Math.random();
      if (levelPicker < 0.5) {
        status = 200;
        level = 'info';
      } else if (levelPicker < 0.80) {
        status = 401;
        level = 'warn';
      } else {
        status = 403;
        level = 'error';
      }
    } else {
      path = '/api/v1/payment/charge';
      method = 'POST';
      const checkPicker = Math.random();
      if (checkPicker < 0.85) {
        status = 201;
        level = 'info';
      } else if (checkPicker < 0.95) {
        status = 402;
        level = 'warn';
      } else {
        status = 502;
        level = 'error';
      }
    }

    const minutesAgo = Math.floor((i * 6.5) + (Math.random() * 5));
    const timestamp = new Date(baseDate.getTime() - minutesAgo * 60 * 1000);

    const ip = `${Math.floor(Math.random() * 210 + 20)}.${Math.floor(Math.random() * 254)}.${Math.floor(Math.random() * 254)}.${Math.floor(Math.random() * 254)}`;
    const bytes = level === 'error' ? 0 : Math.floor(Math.random() * 14500) + 120;
    const country = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
    const userAgent = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
    const fileNum = 1000 + i;
    const archiveType = Math.random() > 0.4 ? 'zip' : 'tar.gz';
    const archive_name = `${indexName.replace(/[^a-zA-Z0-9_-]/g, '_')}_payload_${fileNum}.${archiveType}`;
    const download_url = `/api/s3/proxy-download?key=${archive_name}`;

    logs.push({
      _id: id,
      _index: indexName,
      timestamp: timestamp.toISOString(),
      level,
      method,
      status,
      request_path: path,
      ip,
      bytes,
      country,
      user_agent: userAgent,
      download_url,
      archive_name,
    });
  }

  return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}
